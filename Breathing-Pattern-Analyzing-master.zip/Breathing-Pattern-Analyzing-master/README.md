# Breathing-Pattern-Analyzing
Breathing rate at different yogic positions.
We are calculating breathing pattern of different age group during exercise or after exercise.We are using microphone to get the breathing 
signal after that we are preprocessing it using MATLAB at that time we are removing unwanted Noise and in lastly we are able to find breathing 
rate per minute. Also since our signal can flucate little bit we have to take care Minimum number of sample which we are seprating the signal.
